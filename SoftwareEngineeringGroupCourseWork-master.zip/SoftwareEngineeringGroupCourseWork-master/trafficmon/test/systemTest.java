import com.sun.org.apache.bcel.internal.generic.NEW;
import static org.hamcrest.core.Is.is;
import static org.hamcrest.MatcherAssert.assertThat;
import com.trafficmon.CongestionChargeSystem;
import com.trafficmon.Vehicle;
import com.trafficmon.ZoneBoundaryCrossing;
import org.junit.Test;
import java.util.List;
import java.util.concurrent.TimeUnit;



public class systemTest {
    Vehicle vehicle = Vehicle.withRegistration("abcde");
    Vehicle vehicle1 = Vehicle.withRegistration("1");
    Vehicle vehicle2 = Vehicle.withRegistration("2");
    @Test
    public void RegistrationTest(){

        assertThat(vehicle.toString(), is("Vehicle [" + "abcde"+ "]"));
    }

    @Test
    public void equalsTest(){

        assertThat(vehicle1.equals(vehicle2), is(false));
    }
    @Test
    public void minutesBetweenTest(){
        long startTime = 3000000;
        long endTime = 9000000;
        CongestionChargeSystem system = new CongestionChargeSystem();
        assertThat(system.minutesBetween(startTime, endTime), is(100));
    }

    @Test
    public void checkOrderingOfTest() throws InterruptedException {
        CongestionChargeSystem system = new CongestionChargeSystem();
        system.vehicleEnteringZone(vehicle);
        TimeUnit.SECONDS.sleep(2);
        system.vehicleLeavingZone(vehicle);
        system.calculateCharges();
        assertThat(system.checkOrderingOf(system.crossingsByVehicle.get(vehicle)), is(true));
        return ;
    }
}
