import com.trafficmon.Vehicle;
import org.junit.Test;
import static org.hamcrest.core.Is.is;
import static org.hamcrest.MatcherAssert.assertThat;


public class VehicleTest {

    @Test
    public void RegistrationTest(){
        Vehicle vehicle = Vehicle.withRegistration("abcde");
        assertThat(vehicle.toString(), is("Vehicle [" + "abcde"+ "]"));
    }

    @Test
    public void equalsTest(){
        Vehicle vehicle1 = Vehicle.withRegistration("1");
        Vehicle vehicle2 = Vehicle.withRegistration("2");
        assertThat(vehicle1.equals(vehicle2), is(false));
    }


}